package com.geminifontplus

import android.accessibilityservice.AccessibilityService
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.FrameLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

class FontPlusService : AccessibilityService() {

    private data class Cand(val text: String, val rect: Rect, val pkg: String)

    private class Ctx(val sw: Int, val sh: Int, val pkg: String) {
        val out = ArrayList<Cand>()
        val dump = StringBuilder()
        var markerLeft = 0
        var lines = 0
    }

    companion object {
        const val PKG_GOOGLE = "com.google.android.googlequicksearchbox"
        const val PKG_GEMINI = "com.google.android.apps.bard"
        const val PKG_CHROME = "com.android.chrome"
        @Volatile var lastDump: String = ""
        private val MARKER = Regex("(?i)^\\s*(tradu(ção|zido|zir|ções)|translat(ion|ed|e)).{0,40}$")
    }

    private val handler = Handler(Looper.getMainLooper())
    private val refreshRunnable = Runnable { refresh() }
    private var wm: WindowManager? = null
    private var overlay: FrameLayout? = null
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> schedule() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefListener)
        ensureOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        val p = e.packageName?.toString()
        if (p == packageName) return
        val showing = (overlay?.childCount ?: 0) > 0
        if (!showing && p !in allowedPackages()) return
        schedule()
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefListener) } catch (_: Exception) {}
        try { overlay?.let { wm?.removeView(it) } } catch (_: Exception) {}
        overlay = null
        super.onDestroy()
    }

    private fun schedule() {
        handler.removeCallbacks(refreshRunnable)
        handler.postDelayed(refreshRunnable, 150)
    }

    private fun allowedPackages(): Set<String> {
        val s = HashSet<String>()
        if (!Prefs.bool(this, Prefs.K_ENABLED)) return s
        if (Prefs.bool(this, Prefs.K_GOOGLE)) s.add(PKG_GOOGLE)
        if (Prefs.bool(this, Prefs.K_GEMINI)) s.add(PKG_GEMINI)
        if (Prefs.bool(this, Prefs.K_CHROME)) s.add(PKG_CHROME)
        return s
    }

    private fun ensureOverlay(): FrameLayout {
        overlay?.let { return it }
        val f = FrameLayout(this)
        f.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm?.addView(f, lp)
        overlay = f
        return f
    }

    private fun refresh() {
        try {
            val ov = ensureOverlay()
            val allowed = allowedPackages()
            val scale = Prefs.percent(this) / 100f
            if (allowed.isEmpty() || scale <= 1.001f) { ov.removeAllViews(); return }

            val dm = resources.displayMetrics
            val sw = if (ov.width > 0) ov.width else dm.widthPixels
            val sh = if (ov.height > 0) ov.height else dm.heightPixels

            val roots = ArrayList<AccessibilityNodeInfo>()
            try {
                for (w in windows) { w.root?.let { roots.add(it) } }
            } catch (_: Exception) {}
            if (roots.isEmpty()) rootInActiveWindow?.let { roots.add(it) }

            val all = ArrayList<Cand>()
            val dump = StringBuilder()
            for (r in roots) {
                val pkg = r.packageName?.toString() ?: continue
                if (pkg == packageName || pkg !in allowed) continue
                val ctx = Ctx(sw, sh, pkg)
                walk(r, ctx, 0)
                all.addAll(ctx.out)
                dump.append("== ").append(pkg).append("  tela ").append(sw).append("x").append(sh)
                    .append("  candidatos=").append(ctx.out.size).append('\n').append(ctx.dump).append('\n')
            }
            if (dump.isNotEmpty()) lastDump = dump.toString()

            draw(ov, all, scale, sw, sh)
        } catch (e: Exception) {
            lastDump = "Erro: " + e
        }
    }

    private fun walk(n: AccessibilityNodeInfo, ctx: Ctx, depth: Int) {
        if (depth > 60) return
        if (n.isVisibleToUser) {
            val t = n.text?.toString()
            if (!t.isNullOrBlank()) {
                val r = Rect()
                n.getBoundsInScreen(r)
                val cls = n.className?.toString() ?: ""
                val clickable = n.isClickable || n.isEditable || cls.endsWith("Button") || cls.endsWith("EditText")
                var cand = false
                if (r.width() > 20 && r.height() > 10 && t.trim().length >= 2) {
                    if (ctx.pkg == PKG_GOOGLE) {
                        val cy = r.centerY()
                        cand = !clickable && cy > ctx.sh * 0.12f && cy < ctx.sh * 0.84f
                    } else {
                        if (t.length <= 50 && MARKER.containsMatchIn(t)) {
                            ctx.markerLeft = 8
                        } else if (ctx.markerLeft > 0 && !clickable && t.length >= 12) {
                            cand = true
                            ctx.markerLeft--
                        }
                    }
                }
                if (cand) ctx.out.add(Cand(t, r, ctx.pkg))
                if (ctx.lines < 80) {
                    ctx.lines++
                    ctx.dump.append(if (cand) "[+] " else "[ ] ")
                        .append(cls.substringAfterLast('.')).append(if (clickable) " clic " else " ")
                        .append(r.flattenToString()).append(" \"").append(t.replace('\n', ' ').take(40)).append("\"\n")
                }
            }
        }
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            walk(c, ctx, depth + 1)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun layoutFor(text: CharSequence, size: Float, w: Int, tp: TextPaint): StaticLayout {
        tp.textSize = size
        return StaticLayout.Builder.obtain(text, 0, text.length, tp, max(w, 1))
            .setAlignment(Layout.Alignment.ALIGN_CENTER).build()
    }

    private fun fit(text: CharSequence, w: Int, h: Int, tp: TextPaint): Float {
        var lo = 8f
        var hi = min(160f, max(h.toFloat(), 12f))
        repeat(12) {
            val mid = (lo + hi) / 2f
            if (layoutFor(text, mid, w, tp).height <= h) lo = mid else hi = mid
        }
        return max(lo, 10f)
    }

    private fun draw(ov: FrameLayout, cands: List<Cand>, scale: Float, sw: Int, sh: Int) {
        ov.removeAllViews()
        if (cands.isEmpty()) return
        val loc = IntArray(2)
        ov.getLocationOnScreen(loc)
        val pad = dp(8)
        val margin = dp(6)
        val gap = dp(4)
        val placed = ArrayList<Rect>()
        val tp = TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG)

        for (c in cands.sortedBy { it.rect.top }) {
            val r = c.rect
            val base = fit(c.text, max(r.width() - 2 * pad, dp(40)), r.height(), tp)
            var size = base * scale
            val boxW = min(sw - 2 * margin, (r.width() * (1f + (scale - 1f) * 0.3f)).toInt()).coerceAtLeast(dp(60))
            val innerW = boxW - 2 * pad
            val maxH = (sh * 0.55f).toInt()
            var lay = layoutFor(c.text, size, innerW, tp)
            while (lay.height > maxH && size > base) {
                size *= 0.92f
                lay = layoutFor(c.text, size, innerW, tp)
            }
            val boxH = lay.height + 2 * pad + dp(2)

            val topLimit = if (c.pkg == PKG_GOOGLE) (sh * 0.12f).toInt() else margin
            val bottomLimit = if (c.pkg == PKG_GOOGLE) (sh * 0.84f).toInt() else sh - margin

            val left = (r.centerX() - loc[0] - boxW / 2).coerceIn(margin, max(margin, sw - boxW - margin))
            var top = r.centerY() - loc[1] - boxH / 2
            top = max(top, topLimit)
            var tries = 0
            while (tries < 12) {
                val box = Rect(left, top, left + boxW, top + boxH)
                val hit = placed.firstOrNull { Rect.intersects(it, box) } ?: break
                top = hit.bottom + gap
                tries++
            }
            if (top + boxH > bottomLimit) top = max(topLimit, bottomLimit - boxH)
            placed.add(Rect(left, top, left + boxW, top + boxH))

            val tv = TextView(this)
            tv.text = c.text
            tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, size)
            tv.setTextColor(Color.parseColor("#111111"))
            tv.gravity = Gravity.CENTER
            tv.setPadding(pad, pad, pad, pad)
            tv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            tv.background = GradientDrawable().apply {
                setColor(Color.parseColor("#F5FFFFFF"))
                cornerRadius = dp(16).toFloat()
            }
            val lp = FrameLayout.LayoutParams(boxW, boxH, Gravity.TOP or Gravity.START)
            lp.leftMargin = left
            lp.topMargin = top
            ov.addView(tv, lp)
        }
    }
}

package com.geminifontplus

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvPercent: TextView
    private lateinit var tvPreview: TextView
    private lateinit var btnMinus: MaterialButton
    private lateinit var btnPlus: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvPercent = findViewById(R.id.tvPercent)
        tvPreview = findViewById(R.id.tvPreview)
        btnMinus = findViewById(R.id.btnMinus)
        btnPlus = findViewById(R.id.btnPlus)

        btnMinus.setOnClickListener { step(-50) }
        btnPlus.setOnClickListener { step(50) }

        bindSwitch(R.id.swEnabled, "enabled")
        bindSwitch(R.id.swGoogle, Prefs.K_GOOGLE)
        bindSwitch(R.id.swGemini, Prefs.K_GEMINI)
        bindSwitch(R.id.swChrome, Prefs.K_CHROME)

        findViewById<MaterialButton>(R.id.btnAccess).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<MaterialButton>(R.id.btnReset).setOnClickListener {
            Prefs.setPercent(this, 100)
            render()
        }
        findViewById<MaterialButton>(R.id.btnDiag).setOnClickListener { showDiag() }

        val v = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "?" }
        findViewById<TextView>(R.id.tvVersion).text = "Versão $v • tudo fica salvo só neste aparelho"
        render()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun bindSwitch(id: Int, key: String) {
        val sw = findViewById<MaterialSwitch>(id)
        val k = if (key == "enabled") Prefs.K_ENABLED else key
        sw.isChecked = Prefs.bool(this, k)
        sw.setOnCheckedChangeListener { _, checked ->
            Prefs.setBool(this, k, checked)
            updateStatus()
        }
    }

    private fun step(d: Int) {
        Prefs.setPercent(this, Prefs.percent(this) + d)
        render()
    }

    private fun render() {
        val p = Prefs.percent(this)
        tvPercent.text = "$p%"
        tvPreview.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f * p / 100f)
        btnMinus.isEnabled = p > 100
        btnPlus.isEnabled = p < 500
    }

    private fun serviceOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(packageName) && s.contains("FontPlusService")
    }

    private fun updateStatus() {
        val on = serviceOn()
        val enabled = Prefs.bool(this, Prefs.K_ENABLED)
        when {
            !on -> {
                tvStatus.text = "● Serviço de acessibilidade desligado. Toque no botão abaixo e ative “Gemini Font+”."
                tvStatus.setTextColor(getColor(R.color.bad))
            }
            !enabled -> {
                tvStatus.text = "● Serviço ligado, ampliação pausada."
                tvStatus.setTextColor(Color.parseColor("#B06000"))
            }
            else -> {
                tvStatus.text = "● Funcionando. Abra o Google/Gemini e traduza."
                tvStatus.setTextColor(getColor(R.color.ok))
            }
        }
    }

    private fun showDiag() {
        val text = FontPlusService.lastDump.ifBlank {
            "Nada capturado ainda.\n\n1) Ative o serviço de acessibilidade.\n2) Abra a tradução (Circle to Search/Gemini).\n3) Volte aqui e abra o Diagnóstico."
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("O que o app enxerga")
            .setMessage(text)
            .setPositiveButton("Copiar") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("diagnostico", text))
                Toast.makeText(this, "Copiado", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Fechar", null)
            .show()
    }
}

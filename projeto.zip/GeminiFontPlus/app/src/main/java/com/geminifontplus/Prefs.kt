package com.geminifontplus

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val FILE = "gemini_font_plus"
    const val K_PERCENT = "percent"
    const val K_ENABLED = "enabled"
    const val K_GOOGLE = "t_google"
    const val K_GEMINI = "t_gemini"
    const val K_CHROME = "t_chrome"

    fun sp(c: Context): SharedPreferences = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun percent(c: Context) = sp(c).getInt(K_PERCENT, 200)
    fun setPercent(c: Context, v: Int) = sp(c).edit().putInt(K_PERCENT, v.coerceIn(100, 500)).apply()

    fun bool(c: Context, key: String) = sp(c).getBoolean(key, true)
    fun setBool(c: Context, key: String, v: Boolean) = sp(c).edit().putBoolean(key, v).apply()
}
